# Sales Data Dashboard (Power BI)

This project presents an interactive Power BI dashboard for sales data analytics. 
It visualizes KPIs such as revenue, profit margin, and customer growth using DAX functions.

## Tools
- Power BI
- DAX
- Excel (data source)

## Features
- Interactive slicers and filters
- Dynamic visualization of trends
- KPI cards and regional analysis
